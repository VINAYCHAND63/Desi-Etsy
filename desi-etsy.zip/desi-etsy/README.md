# Desi Etsy

This is a skeleton MERN project for the Desi Etsy marketplace. It includes backend (Express + MongoDB) and frontend (React + Vite) starter code, Razorpay integration hooks, and basic auth/product/order flows.

## Quick start (backend)
1. cd backend
2. cp .env.example .env and fill values
3. npm install
4. npm run dev

## Quick start (frontend)
1. cd frontend
2. npm install
3. npm run dev

