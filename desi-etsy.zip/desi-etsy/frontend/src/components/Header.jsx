import React from 'react';
export default function Header(){ return <header style={{padding:12,background:'#fafafa',borderBottom:'1px solid #eee'}}>Desi Etsy — <a href='/'>Home</a> | <a href='/products'>Products</a></header>; }
