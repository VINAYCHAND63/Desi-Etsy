import React, { createContext, useState } from 'react';
export const CartContext = createContext();
export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState(() => JSON.parse(localStorage.getItem('cart')) || []);
  const add = (item) => { const next = [...cart, item]; setCart(next); localStorage.setItem('cart', JSON.stringify(next)); };
  const remove = (idx) => { const next = cart.filter((_,i)=>i!==idx); setCart(next); localStorage.setItem('cart', JSON.stringify(next)); };
  const clear = () => { setCart([]); localStorage.removeItem('cart'); };
  return <CartContext.Provider value={{ cart, add, remove, clear }}>{children}</CartContext.Provider>
}
