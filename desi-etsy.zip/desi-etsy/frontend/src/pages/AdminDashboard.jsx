import React from 'react';
export default function AdminDashboard(){ return <div style={{padding:20}}>Admin Dashboard (approve products)</div>; }
