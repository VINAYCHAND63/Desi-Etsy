import React from 'react';
export default function ProductList(){ return <div style={{padding:20}}>Product List (filters TBD)</div>; }
