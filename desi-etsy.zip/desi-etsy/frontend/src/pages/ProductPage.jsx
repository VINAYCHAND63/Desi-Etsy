import React from 'react';
export default function ProductPage(){ return <div style={{padding:20}}>Product Page</div>; }
