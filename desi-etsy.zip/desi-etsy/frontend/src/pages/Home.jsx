import React, { useEffect, useState } from 'react';
import api from '../api/axios';

export default function Home(){
  const [items,setItems] = useState([]);
  useEffect(()=>{ api.get('/products').then(r=>setItems(r.data.items)).catch(console.error); },[]);
  return (
    <div style={{padding:20}}>
      <h1>Featured Handmade Products</h1>
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))',gap:12}}>
        {items.map(p=> (
          <div key={p._id} style={{border:'1px solid #ddd',padding:12}}>
            <img src={p.images?.[0]||''} alt={p.title} style={{width:'100%',height:150,objectFit:'cover'}} />
            <h3>{p.title}</h3>
            <p>₹{p.price}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
