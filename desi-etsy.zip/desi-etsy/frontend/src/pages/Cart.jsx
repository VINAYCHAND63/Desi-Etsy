import React from 'react';
export default function Cart(){ return <div style={{padding:20}}>Cart</div>; }
