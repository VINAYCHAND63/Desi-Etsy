import React from 'react';
export default function ArtisanDashboard(){ return <div style={{padding:20}}>Artisan Dashboard (create products)</div>; }
