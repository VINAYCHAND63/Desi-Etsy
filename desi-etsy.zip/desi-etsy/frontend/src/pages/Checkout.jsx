import React, { useContext } from 'react';
import { CartContext } from '../context/CartContext';
import api from '../api/axios';

export default function Checkout(){
  const { cart, clear } = useContext(CartContext);
  const makePayment = async () => {
    const items = cart.map(c=>({ product: c._id, qty: c.qty || 1 }));
    const { data } = await api.post('/orders/create', { items });
    const options = {
      key: import.meta.env.VITE_RAZORPAY_KEY || '',
      amount: data.amount,
      currency: data.currency,
      name: 'Desi Etsy',
      order_id: data.orderId,
      handler: async function(response){
        await api.post('/orders/verify', { ...response, dbOrderId: data.dbOrderId });
        alert('Payment successful');
        clear();
      }
    };
    const rzp = new window.Razorpay(options);
    rzp.open();
  };
  return (
    <div style={{padding:20}}>
      <h2>Checkout</h2>
      <button onClick={makePayment}>Pay with Razorpay</button>
    </div>
  );
}
