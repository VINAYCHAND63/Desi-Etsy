const express = require('express');
const router = express.Router();
const auth = require('../middlewares/auth');
const admin = require('../middlewares/admin');
const ctrl = require('../controllers/adminController');

router.get('/products/pending', auth, admin, ctrl.listPendingProducts);
router.put('/product/:id/approve', auth, admin, ctrl.approveProduct);
router.put('/artisan/:id/verify', auth, admin, ctrl.verifyArtisan);
module.exports = router;
