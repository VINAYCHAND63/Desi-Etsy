const express = require('express');
const router = express.Router();
const auth = require('../middlewares/auth');
const ctrl = require('../controllers/orderController');

router.post('/create', auth, ctrl.createOrder);
router.post('/verify', auth, ctrl.verifyPayment);
router.get('/mine', auth, ctrl.getOrdersForUser);
router.put('/:id/status', auth, ctrl.updateStatus);
module.exports = router;
