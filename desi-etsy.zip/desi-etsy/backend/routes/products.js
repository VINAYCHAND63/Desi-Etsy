const express = require('express');
const router = express.Router();
const auth = require('../middlewares/auth');
const upload = require('../middlewares/upload');
const ctrl = require('../controllers/productController');

router.get('/', ctrl.getProducts);
router.get('/:id', ctrl.getProductById);
router.post('/', auth, upload.array('images',5), ctrl.createProduct);
router.get('/artisan/mine', auth, ctrl.getArtisanProducts);
module.exports = router;
