const Product = require('../models/Product');
const User = require('../models/User');

exports.listPendingProducts = async (req,res)=>{
  const items = await Product.find({ isApproved: false }).populate('artisan');
  res.json(items);
};
exports.approveProduct = async (req,res)=>{
  const p = await Product.findByIdAndUpdate(req.params.id,{ isApproved: true },{ new:true });
  res.json(p);
};
exports.verifyArtisan = async (req,res)=>{
  const user = await User.findByIdAndUpdate(req.params.id,{ isVerified:true },{ new:true });
  res.json(user);
};
