const Order = require('../models/Order');
const Product = require('../models/Product');
const rzp = require('../utils/razorpay');

exports.createOrder = async (req,res) => {
  const { items } = req.body;
  const detailed = await Promise.all(items.map(async it => {
    const p = await Product.findById(it.product);
    return { product: p._id, qty: it.qty, price: p.price };
  }));
  const total = detailed.reduce((s,i)=> s + i.qty*i.price, 0);
  const options = { amount: Math.round(total*100), currency: 'INR' };
  const order = await rzp.orders.create(options);
  const dbOrder = await Order.create({ customer: req.user._id, items: detailed, totalAmount: total, payment:{ razorpayOrderId: order.id, paid:false } });
  res.json({ orderId: order.id, amount: options.amount, currency: options.currency, dbOrderId: dbOrder._id });
};

exports.verifyPayment = async (req,res) => {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature, dbOrderId } = req.body;
  const crypto = require('crypto');
  const generated_signature = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET).update(razorpay_order_id + '|' + razorpay_payment_id).digest('hex');
  if(generated_signature === razorpay_signature){
    await Order.findByIdAndUpdate(dbOrderId, { 'payment.razorpayPaymentId': razorpay_payment_id, 'payment.razorpaySignature': razorpay_signature, 'payment.paid': true });
    res.json({ ok:true });
  }else res.status(400).json({ ok:false });
};

exports.updateStatus = async (req,res)=>{
  const { status } = req.body;
  const o = await Order.findByIdAndUpdate(req.params.id, { status }, { new:true });
  res.json(o);
};

exports.getOrdersForUser = async (req,res)=>{
  const orders = await Order.find({ customer: req.user._id }).populate('items.product');
  res.json(orders);
};
