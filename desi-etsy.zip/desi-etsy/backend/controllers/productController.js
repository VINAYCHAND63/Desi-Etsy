const Product = require('../models/Product');

exports.createProduct = async (req,res) => {
  try{
    const data = req.body;
    data.artisan = req.user._id;
    if(req.files) data.images = req.files.map(f => '/uploads/'+f.filename);
    const p = await Product.create(data);
    res.json(p);
  }catch(err){ res.status(500).json({message:err.message}); }
};

exports.getProducts = async (req,res) => {
  const { q, category, min, max, page=1, limit=12 } = req.query;
  const filter = { isApproved: true };
  if(category) filter.category = category;
  if(q) filter.title = { $regex: q, $options: 'i' };
  if(min || max) filter.price = {};
  if(min) filter.price.$gte = Number(min);
  if(max) filter.price.$lte = Number(max);
  const skip = (page-1) * limit;
  const items = await Product.find(filter).skip(skip).limit(Number(limit)).populate('artisan','name');
  const total = await Product.countDocuments(filter);
  res.json({ items, total });
};

exports.getProductById = async (req,res)=>{
  const p = await Product.findById(req.params.id).populate('artisan','name email');
  res.json(p);
};

exports.getArtisanProducts = async (req,res)=>{
  const items = await Product.find({ artisan: req.user._id });
  res.json(items);
};
